symfony2-guestbook-webservice
=============================

resetful webservice symfony2 guestbook
