<?php return array (
  'api_1_new_guest' => 
  array (
    0 => 'GET',
  ),
  'api_1_get_guests' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'api_1_post_guest' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'api_1_get_guest' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'PATCH',
  ),
  'api_1_put_guest' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'PATCH',
  ),
  'api_1_patch_guest' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'PATCH',
  ),
  'nelmio_api_doc_index' => 
  array (
    0 => 'GET',
  ),
);