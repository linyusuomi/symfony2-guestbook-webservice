<?php

/* LinGuestbookBundle:Index:getGuests.html.twig */
class __TwigTemplate_98fe8d75cafe429806a8f90d603787413dc392cc2e13e6d40ae5a5d9ab4b05fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 2
        echo "    <h1 class=\"title\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("guest.list", array(), "LinGuestbookBundle"), "html", null, true);
        echo "</h1>

    <ul id=\"page-list\">
        ";
        // line 5
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["guests"]) ? $context["guests"] : $this->getContext($context, "guests")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["guest"]) {
            // line 6
            echo "            <li>

                <img src=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "getBaseURL", array(), "method"), "html", null, true);
            echo "/../uploads/";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["guest"]) ? $context["guest"] : $this->getContext($context, "guest")), "path"), "html", null, true);
            echo "\" alt=\"Smiley face\" height=\"70\" width=\"70\">
                ";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["guest"]) ? $context["guest"] : $this->getContext($context, "guest")), "name"), "html", null, true);
            echo "
                <a href=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("api_1_get_guest", array("id" => $this->getAttribute((isset($context["guest"]) ? $context["guest"] : $this->getContext($context, "guest")), "id"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["guest"]) ? $context["guest"] : $this->getContext($context, "guest")), "phone"), "html", null, true);
            echo "</a>
                ";
            // line 12
            echo "                ";
            // line 13
            echo "            </li>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 15
            echo "            <li>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("guest.list.empty", array(), "LinGuestbookBundle"), "html", null, true);
            echo "</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['guest'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    </ul>
    <p>
        <a href=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("api_1_new_guest");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("guest.new.link", array(), "LinGuestbookBundle"), "html", null, true);
        echo "</a>
    </p>
";
    }

    public function getTemplateName()
    {
        return "LinGuestbookBundle:Index:getGuests.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  79 => 19,  75 => 17,  66 => 15,  60 => 13,  58 => 12,  52 => 10,  48 => 9,  42 => 8,  38 => 6,  33 => 5,  26 => 2,  20 => 1,);
    }
}
