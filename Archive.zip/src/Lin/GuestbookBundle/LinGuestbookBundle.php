<?php

namespace Lin\GuestbookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LinGuestbookBundle extends Bundle
{
}
